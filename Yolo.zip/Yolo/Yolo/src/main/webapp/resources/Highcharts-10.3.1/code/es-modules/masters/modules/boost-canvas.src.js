/**
 * @license Highcharts JS v10.3.1 (2022-10-31)
 * @module highcharts/modules/boost-canvas
 * @requires highcharts
 *
 * Boost module
 *
 * (c) 2010-2021 Highsoft AS
 * Author: Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/BoostCanvas.js';
