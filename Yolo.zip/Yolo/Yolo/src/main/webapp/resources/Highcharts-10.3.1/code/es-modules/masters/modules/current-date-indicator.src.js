/**
 * @license Highcharts Gantt JS v10.3.1 (2022-10-31)
 * @module highcharts/modules/current-date-indicator
 * @requires highcharts
 *
 * CurrentDateIndicator
 *
 * (c) 2010-2021 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/CurrentDateIndication.js';
