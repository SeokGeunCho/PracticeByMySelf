package com.yolo.hr.josh.model;

public interface InterAdminDAO {

}
