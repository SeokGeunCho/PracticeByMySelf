package com.yolo.hr.login.model;

public class LoginVO {

}
