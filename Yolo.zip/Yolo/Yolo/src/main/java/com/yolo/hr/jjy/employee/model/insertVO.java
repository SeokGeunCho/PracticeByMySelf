package com.yolo.hr.jjy.employee.model;

public class insertVO {

	private String name;
	private String email;
	private String hiredate;
	private String time_salary;
	private String fk_deptno;
	private String position;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getHiredate() {
		return hiredate;
	}
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
	public String getTime_salary() {
		return time_salary;
	}
	public void setTime_salary(String time_salary) {
		this.time_salary = time_salary;
	}
	public String getFk_deptno() {
		return fk_deptno;
	}
	public void setFk_deptno(String fk_deptno) {
		this.fk_deptno = fk_deptno;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	
	
	
	
}
