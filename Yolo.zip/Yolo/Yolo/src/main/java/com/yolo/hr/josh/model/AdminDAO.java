package com.yolo.hr.josh.model;

public class AdminDAO implements InterAdminDAO {

}
