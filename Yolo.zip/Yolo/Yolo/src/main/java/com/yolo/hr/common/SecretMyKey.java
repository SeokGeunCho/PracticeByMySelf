package com.yolo.hr.common;

public class SecretMyKey {

	public final static String KEY = "abcd0070#aclass$";
	
}
